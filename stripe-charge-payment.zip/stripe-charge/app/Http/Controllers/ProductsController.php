<?php

namespace App\Http\Controllers;

use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class ProductsController extends Controller
{
    public function index(){
        $products = products::all();
        return view('products')->with('products',$products);
    }

    public function getProduct(Request $request, $product_id){
        $product = products::where('product_id',$request->product_id)->first();
        return view('payment')->with('product',$product);
    }
}
