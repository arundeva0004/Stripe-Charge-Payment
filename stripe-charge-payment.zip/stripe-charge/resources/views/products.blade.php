

@extends('layout')

@section('content')

    <style>
        .section-grid{
        display: flex;
        padding-left: 25px;
        padding-right: 25px;
        }
        .grid-prod{
        flex: 1 1 auto;
        display: flex;
        flex-flow: row wrap;
        }
        .prod-grid{
            flex: 1 1 25%;
            margin:2%;
            padding:12px;
            border: 2px solid #000;
        }
    </style>
    <div style="margin-top: 10px;">
        <h3> Products </h3>
    </div>

    <div style="margin-top: 5px;">

        <div class="container">
            <!--Product Grid-->
            <div id="div1">
                <section class="section-grid">
                    <div class="grid-prod">
                        @foreach($products as $product)
                            <div class="prod-grid">
                                <img src="{{$product->thumbnail}}" width="450px" height="200px" alt="{{$product->name}}">

                                <h2>{{$product->name}} {{$product->product_id}} </h2>

                                <div class="col-sm-12 row">
                                    <div class="col-sm-6">
                                        <h3> Rs. {{$product->price}} </h3>
                                    </div>
                                    <div class="col-sm-6">
                                        <a href="{{ url('/payment/'.$product->product_id)}}"
                                           title="View Student"><button class="btn btn-success"> Buy Now</button></a>

                                    </div>
                                </div>


                            </div>
                        @endforeach
                    </div>
                </section>
            </div>
    </div>

@endsection
